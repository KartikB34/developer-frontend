export const Jobs = [
    {
      title: "Front-end Developer",
      experience: "2-years",
      ctc: "10LPA",
      status: "Completed",
    },
    {
      title: "Back-end Developer",
      experience: "1-years",
      ctc: "10LPA",
      status: "No selection",
    },
    {
      title: "Graphic Designer",
      experience: "2-years",
      ctc: "10LPA",
      status: "Completed",
    },
    {
      title: "Marketing manager",
      experience: "1-years",
      ctc: "10LPA",
      status: "not selection",
    },
  ];