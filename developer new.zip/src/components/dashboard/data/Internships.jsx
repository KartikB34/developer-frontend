export const Internships = [
    {
      title: "Front-end Internship",
      experience: "2-years",
      stipend: "50K",
      status: "Completed",
    },
    {
      title: "Back-end Internship",
      experience: "1-years",
      stipend: "50K",
      status: "No selection",
    },
    {
      title: "Graphic Designer Internship",
      experience: "2-years",
      stipend: "50K",
      status: "Completed",
    },
    {
      title: "Marketing Internship",
      experience: "1-years",
      stipend: "50K",
      status: "not selection",
    },
  ];