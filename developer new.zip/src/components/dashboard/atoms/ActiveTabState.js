import {atom} from 'recoil'

export const ActiveTabState  = atom({
    key:"ActiveTabState",
    default:0,
})