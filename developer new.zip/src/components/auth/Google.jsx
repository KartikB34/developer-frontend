import React, { useEffect } from 'react'
import { useSearchParams } from 'react-router-dom';
import Axios from "axios";

const Google = () => {
    const API = process.env.REACT_APP_API_ENDPOINT;
    const [searchParams] = useSearchParams();
    const sendBackend = async (code) => {
        const response = await Axios.get(`${API}/api/v1/user/googleUserInfo`, {
           params : {code}
          });
    }
    useEffect(()=>{
        let code = searchParams.get('code');
        console.log(code)
        sendBackend(code )
    },[])
   

  return (
    <div>
      Google
    </div>
  )
}

export default Google
